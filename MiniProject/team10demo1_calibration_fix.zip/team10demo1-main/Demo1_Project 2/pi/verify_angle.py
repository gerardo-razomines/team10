# this checks the reported marker angle against positions measured with a tape measure
# run it once after calibrating and before the demo. it is what would have caught our old 6 degree error.
#
# how to use it:
#   - put the camera at its demo position and run: python3 verify_angle.py
#   - lay a tape measure straight out from the camera lens along the camera axis (straight ahead)
#   - place marker 0 at a spot, measure FORWARD distance along the tape and SIDEWAYS distance
#     from the tape to the marker center (left of the camera = positive, right = negative)
#   - type the two numbers in inches, e.g. "36 6". the true angle is atan(sideways / forward)
#   - do at least 5 spots: straight ahead, a couple left, a couple right, near and far
#   - press Enter on an empty line to finish. it reports the error and offers to save a constant trim
import json
import math
import time
from pathlib import Path

import cv2
import numpy as np

from vision_common import (detector, load_calibration, load_config, marker_bearing, open_camera,
                           orient_frame, saved_focus)

CONFIG = Path(__file__).with_name("camera_config.json")


def measure(cam, cfg, detect, K, dist, frames=40, timeout=8.0):
    # grab a bunch of frames and return the median raw bearing (no trim applied) and the spread
    values = []
    start = time.monotonic()
    while len(values) < frames and time.monotonic() - start < timeout:
        ok, raw = cam.read()
        if not ok:
            raise RuntimeError("the camera stopped returning frames")
        frame = orient_frame(raw, cfg)
        corners, ids, _ = detect(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
        if ids is None:
            continue
        for i, marker_id in enumerate(ids.flatten()):
            if int(marker_id) == cfg["marker_id"]:
                values.append(marker_bearing(corners[i], K, dist))
                break
    if len(values) < 5:
        return None, None
    return float(np.median(values)), float(np.std(values))


def main():
    cfg = load_config(CONFIG)
    K, dist, _ = load_calibration(cfg["calibration_file"], cfg)
    detect = detector(cfg["dictionary"])
    trim = cfg["angle_offset_deg"]
    cam = open_camera(cfg, saved_focus(cfg["calibration_file"]))
    rows = []
    print("place marker 0, measure its position, type it in. Enter on an empty line finishes.")
    print("measure from the camera LENS. left of the camera is positive.")
    print(f"current trim in camera_config.json: {trim:+.3f} deg\n")
    try:
        while True:
            text = input("forward_in sideways_in (Enter to finish): ").strip()
            if not text:
                break
            try:
                forward, sideways = (float(x) for x in text.replace(",", " ").split())
                if forward <= 0:
                    raise ValueError
            except ValueError:
                print("  type two numbers like: 36 -6   (forward must be positive)")
                continue
            true = math.degrees(math.atan2(sideways, forward))
            raw, spread = measure(cam, cfg, detect, K, dist)
            if raw is None:
                print("  marker 0 not seen. check lighting / that its in view, then try again")
                continue
            reported = raw - trim
            rows.append((forward, sideways, true, raw))
            print(f"  true {true:+7.2f}   reported {reported:+7.2f}   error {reported - true:+6.2f} deg"
                  f"   (frame-to-frame spread {spread:.2f})")
    finally:
        cam.release()

    if not rows:
        return
    true = np.array([r[2] for r in rows])
    raw = np.array([r[3] for r in rows])
    current = np.mean(np.abs(raw - trim - true))
    bias = float(np.mean(raw - true))
    fixed = np.mean(np.abs(raw - bias - true))
    print(f"\n{len(rows)} spots. average error with current trim: {current:.2f} deg")
    print(f"constant part of the error (best trim): {bias:+.3f} deg -> average error with it: {fixed:.2f} deg")
    # the error that is left after removing the constant part tells you if the calibration itself is good
    if fixed > 0.75:
        print("WARNING: the error left after the trim is still over 0.75 deg. that means the calibration\n"
              "(not just the camera aim) is off. recalibrate with a flat board and more tilted views.")
    # a large error that grows toward the edges usually means the focal length is wrong
    if len(rows) >= 3 and np.ptp(true) > 5:
        slope = np.polyfit(true, raw - bias - true, 1)[0]
        if abs(slope) > 0.02:
            print(f"note: error grows {slope*100:+.1f}% toward the edges, which points at the focal length / calibration")
    if len(rows) >= 3 and input(f"save trim {bias:+.3f} deg to camera_config.json? [y/N]: ").strip().lower() == "y":
        saved = json.loads(CONFIG.read_text())
        saved["angle_offset_deg"] = round(bias, 3)
        CONFIG.write_text(json.dumps(saved, indent=2) + "\n")
        print("saved. marker_angle.py will use it from now on.")


if __name__ == "__main__":
    main()
