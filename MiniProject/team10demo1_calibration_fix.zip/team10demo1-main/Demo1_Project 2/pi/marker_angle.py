# This performs Task 1
# which continuously shows ID 0 bearing on the Adafruit RGB LCD
# this runs without accepting the user commands
# the pi doesn't send motion commands to the arduino

import argparse
import math
import os
import queue
import signal
import threading
import time
from pathlib import Path

import cv2
from camera_preview import CameraPreview

from vision_common import (AngleFilter, detector, load_calibration, load_config, measured_angle,
                           open_camera, orient_frame, saved_focus)


# default to five minutes unless a different run time is given
RUN_SECONDS = 300


class Display:
    # One bounded queue is slow I2C can't build an old-angle backlog
    def __init__(self, cfg):
        # use the lcd dimensions from the camera settings file
        self.columns = cfg["lcd_columns"]
        self.error = None
        import board
        import adafruit_character_lcd.character_lcd_rgb_i2c as lcd_module
        self.lcd = lcd_module.Character_LCD_RGB_I2C(board.I2C(), self.columns, cfg["lcd_rows"])
        self.lcd.clear()
        # keep only one waiting update so the lcd doesnt fall behind the camera
        self.pending = queue.Queue(maxsize=1)
        self.stopping = threading.Event()
        # write to the lcd in the background so camera capture can keep going
        self.worker = threading.Thread(target=self._run, daemon=True)
        self.worker.start()

    # trim and pad each line so old characters dont stay on the lcd
    def show(self, first, second, color):
        item = (first[:self.columns].ljust(self.columns), second[:self.columns].ljust(self.columns), color)
        try:
            self.pending.put_nowait(item)
        except queue.Full:
            try:
                # if the queue is full, remove the older message and try the newest one
                self.pending.get_nowait()
            except queue.Empty:
                pass
            try:
                self.pending.put_nowait(item)
            except queue.Full:
                pass

    # this is the background loop that actually sends text and colors to the lcd
    def _run(self):
        while not self.stopping.is_set():
            try:
                first, second, color = self.pending.get(timeout=0.1)
            except queue.Empty:
                continue
            try:
                self.lcd.color = color
                self.lcd.cursor_position(0, 0)
                self.lcd.message = first + "\n" + second
            except Exception as exc:
                # save the error so the camera loop can notice it and stop
                self.error = exc
                return

    # ask the lcd worker to stop and give it a short time to finish
    def close(self):
        self.stopping.set()
        self.worker.join(timeout=0.5)


def main():
    parser = argparse.ArgumentParser(description="Marker angle on the physical LCD; preview optional")
    parser.add_argument('--no-preview', action='store_true')
    parser.add_argument('--seconds', type=float, default=RUN_SECONDS, help='run duration; 0 means run until stopped')
    args = parser.parse_args()
    # zero means keep running, but a negative or invalid time doesnt make sense
    if not math.isfinite(args.seconds) or args.seconds < 0:
        parser.error('--seconds must be finite and nonnegative')
    if args.no_preview:
        os.environ['DEMO1_PREVIEW'] = '0'
    # handle a termination request like ctrl+c so cleanup still happens
    def stop_on_signal(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop_on_signal)
    cfg = load_config(Path(__file__).with_name("camera_config.json"))
    # load the saved calibration before starting the angle measurements
    K, dist, image_size = load_calibration(cfg["calibration_file"], cfg)
    detect = detector(cfg["dictionary"])
    display = Display(cfg)
    cam = None
    preview = None
    user_stopped = False
    try:
        preview = CameraPreview("Demo 1 - Marker Angle")
        display.show("Demo 1 camera", "beginning...", [100, 100, 0])
        # FIX: lock the focus at the same value that was used during calibration
        cam = open_camera(cfg, saved_focus(cfg["calibration_file"]))
        smoother = AngleFilter()
        # a zero duration gives this an unlimited run time
        deadline = time.monotonic() + args.seconds if args.seconds else float("inf")
        next_update = 0
        while time.monotonic() < deadline:
            if display.error is not None:
                raise RuntimeError("LCD write isnt working") from display.error
            ok, raw = cam.read()
            if not ok:
                raise RuntimeError("the camera stopped returning frames")
            # keep the image orientation the same as it was during calibration
            frame = orient_frame(raw, cfg)
            if (frame.shape[1], frame.shape[0]) != image_size:
                raise RuntimeError("calibration has a different resolution than what the cameras returning")
            # look for markers in grayscale, then check for the configured marker id
            corners, ids, _ = detect(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
            # start with no angle each frame so we dont reuse an old measurement
            bearing = None
            if ids is not None:
                for i, marker_id in enumerate(ids.flatten()):
                    if int(marker_id) == cfg["marker_id"]:
                        # get the horizontal angle to the marker center, with left being positive
                        # (median of the last few frames, minus the trim from verify_angle.py)
                        bearing = smoother.add(measured_angle(corners[i], K, dist, cfg))
                        break
            if bearing is None:
                smoother.reset()
            preview_text = (f"Marker {cfg['marker_id']}: NOT FOUND" if bearing is None else
                            f"Marker {cfg['marker_id']}: {bearing:+.2f} deg (left positive)")
            # closing the preview also stops this demo loop
            if not preview.show(frame, [preview_text], corners, ids):
                user_stopped = True
                break
            now = time.monotonic()
            # update the lcd and terminal at intervals instead of on every camera frame
            if now >= next_update:
                # show that the marker is missing instead of leaving the previous angle displayed
                if bearing is None:
                    display.show("ID 0 NOT FOUND", "looking for it...", [100, 0, 0])
                    print("ID 0 NOT FOUND", flush=True)
                else:
                    display.show("ID 0 DETECTED", f"Ang:{bearing:+7.2f} deg", [0, 100, 0])
                    print(f"ID 0 bearing {bearing:+.3f} deg (left positive)", flush=True)
                next_update = now + 0.15
        display.show("Demo 1 finished", "stopped" if user_stopped else "the timer expired", [0, 0, 100])
        time.sleep(0.2)
    except KeyboardInterrupt:
        display.show("Demo 1 stopped", "", [0, 0, 100])
        time.sleep(0.2)
    except Exception:
        display.show("CAMERA/LCD ERROR", "check the console", [100, 0, 0])
        time.sleep(0.2)
        raise
    # release the camera and close the preview and lcd worker when the demo ends
    finally:
        if cam is not None:
            cam.release()
        if preview is not None:
            preview.close()
        display.close()


if __name__ == "__main__":
    main()
