#!/usr/bin/env bash
# Demo 1 Project: terminal launcher. Run w/: bash run_project.sh
# stop if a command fails or a variable hasnt been set
set -eu
# start from the folder containing this script, even if we launched it somewhere else
project_pi_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd -- "$project_pi_dir"

# Prefer an existing project virtual environment; otherwise use active Python.
if [[ -x "$project_pi_dir/.venv/bin/python3" ]]; then
    project_python="$project_pi_dir/.venv/bin/python3"
else
    project_python="${PYTHON:-python3}"
fi

# the first argument chooses the mode, and the rest get passed to that script
project_action="${1:-}"
if [[ $# -gt 0 ]]; then shift; fi
# without a mode, just open the terminal control menu
if [[ -z "$project_action" ]]; then
    exec "$project_python" "$project_pi_dir/project.py"
fi

# exec replaces this launcher with the selected python process
case "$project_action" in
    # open the menu without camera windows
    --no-preview)
        exec "$project_python" "$project_pi_dir/project.py" --no-preview "$@"
        ;;
    # run marker angles without a preview or time limit
    headless)
        exec "$project_python" "$project_pi_dir/marker_angle.py" --no-preview --seconds 0 "$@"
        ;;
    # use the saved calibration if its already there and compatible
    1|calibrate)
        exec "$project_python" "$project_pi_dir/calibrate_camera.py" "$@"
        ;;
    # start the marker angle demo with any extra options passed along
    2|demo)
        exec "$project_python" "$project_pi_dir/marker_angle.py" "$@"
        ;;
    # force a new calibration even if theres one saved already
    3|recalibrate)
        exec "$project_python" "$project_pi_dir/calibrate_camera.py" --force "$@"
        ;;
    # check the angles against tape-measure positions after calibrating
    verify)
        exec "$project_python" "$project_pi_dir/verify_angle.py" "$@"
        ;;
    4|exit)
        exit 0
        ;;
    -h|--help|help)
        printf 'use: bash run_project.sh [calibrate|verify|demo|recalibrate|headless|--no-preview] [calibration options]\n'
        printf 'run without arguments for the full project terminal control panel.\n'
        ;;
    # show an error if the selected mode isnt one of the choices
    *)
        printf 'idk what this choioce is: %s. do --help.\n' "$project_action" >&2
        exit 2
        ;;
esac
