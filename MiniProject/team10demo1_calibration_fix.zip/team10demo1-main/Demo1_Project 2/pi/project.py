# this si the demo 1 project control panel that organizes all of the actions that the code does
import argparse
import os
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

# find everything relative to this file so it still works from a different terminal folder
HERE = Path(__file__).resolve().parent
CONFIG = HERE / 'camera_config.json'


def run_script(name, *args):
    # Merge stderr into stdout so IDEs and terminal hosts cannot hide the error.
    from collections import deque
    import tempfile
    log_directory = HERE / 'logs'
    try:
        log_directory.mkdir(exist_ok=True)
    except OSError:
        log_directory = Path(tempfile.gettempdir())
    # give each run its own log name so earlier output doesnt get overwritten
    stamp = time.strftime('%Y%m%d_%H%M%S') + f'_{time.time_ns() % 1000000000:09d}'
    log_path = log_directory / f'{Path(name).stem}_{stamp}.log'
    # keep the last few lines handy to show if the script fails
    last_lines = deque(maxlen=20)
    print(f'Starting {name} with {sys.executable}', flush=True)
    process = None
    with log_path.open('w', encoding='utf-8') as log:
        log.write(f'Python: {sys.executable}\nScript: {HERE / name}\n')
        log.flush()
        try:
            # run the selected script with the same python thats running this menu
            process = subprocess.Popen(
                [sys.executable, '-u', str(HERE / name), *args],
                cwd=str(HERE), stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding='utf-8', errors='replace', bufsize=1)
            try:
                # show the output live and save the same text to the log
                for line in process.stdout:
                    print(line, end='', flush=True)
                    log.write(line)
                    log.flush()
                    last_lines.append(line.rstrip())
                code = process.wait()
            finally:
                process.stdout.close()
        # stop the child script too if ctrl+c is pressed while its running
        except KeyboardInterrupt:
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    # if it doesnt stop after the first request, make it to finish
                    process.kill()
                    process.wait()
            print('\nTest stopped. Returning to project menu.', flush=True)
            return
    # a nonzero exit code means the script failed, so show its recent output
    if code:
        print(f'\n{name} failed (exit {code}). Error output:', flush=True)
        if last_lines:
            print('\n'.join(last_lines), flush=True)
        else:
            print('the process exited without producing any output. '
                  'run the script directly using the python path printed above.', flush=True)
        print(f'Error log: {log_path}', flush=True)
    return code


# read a number and check any limits that were passed in
def number(prompt, low=None, high=None):
    value = float(input(prompt))
    if not math.isfinite(value) or (low is not None and value < low) or (high is not None and value > high):
        raise ValueError('values outside the allowed range.')
    return value


def camera_test(mode):
    import cv2
    from camera_preview import CameraPreview
    from vision_common import (load_config, open_camera, orient_frame, detector, load_calibration,
                               measured_angle, saved_focus)
    cfg = load_config(CONFIG)
    # the basic camera test doesnt need marker detection
    detect = detector(cfg['dictionary']) if mode != 'camera' else None
    # only the angle test needs saved calibration values
    calibration = load_calibration(cfg['calibration_file'], cfg) if mode == 'angle' else None
    preview = CameraPreview({'camera': 'Camera Test', 'markers': 'Marker Detection Test',
                             'angle': 'Marker Angle Test'}[mode])
    cam = None
    print('testing for 30 seconds. Q / Esc / close window or Ctrl+C stops this test.')
    count = 0
    next_print = 0
    started = time.monotonic()
    try:
        cam = open_camera(cfg, saved_focus(cfg['calibration_file']))
        # run the camera check for up to thirty seconds
        while time.monotonic() - started < 30:
            ok, raw = cam.read()
            if not ok:
                raise RuntimeError('cam returned no frame so check USB and camera_index.')
            frame = orient_frame(raw, cfg)
            # check the actual image size against what the settings requested
            size = (frame.shape[1], frame.shape[0])
            if size != (cfg['width'], cfg['height']):
                raise ValueError(f'cam resolution {size} differs from the configured resolution.')
            count += 1
            corners, ids = None, None
            if mode == 'camera':
                lines = [f'Camera OK: {size[0]} x {size[1]}, {count} frames received']
            else:
                corners, ids, _ = detect(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
                # make the detected ids into a normal list so we can check for our marker
                ids_list = [] if ids is None else [int(i) for i in ids.flatten()]
                lines = [f'detected marker IDs: {ids_list}']
                if calibration:
                    if cfg['marker_id'] in ids_list:
                        K, dist, _ = calibration
                        angle = measured_angle(corners[ids_list.index(cfg['marker_id'])], K, dist, cfg)
                        lines.append(f'marker {cfg["marker_id"]}: {angle:+.3f} deg (left positive)')
                    else:
                        lines.append(f'marker {cfg["marker_id"]} wasnt found')
            if not preview.show(frame, lines, corners, ids):
                break
            # print twice a second so the terminal doesnt fill up as fast as the camera runs
            if time.monotonic() >= next_print:
                print(' | '.join(lines), flush=True)
                next_print = time.monotonic() + .5
    finally:
        if cam is not None:
            cam.release()
        preview.close()


# check the lcd text and each backlight color without needing the camera
def lcd_test():
    import board
    import adafruit_character_lcd.character_lcd_rgb_i2c as lcd_module
    cfg = json.loads(CONFIG.read_text())
    lcd = lcd_module.Character_LCD_RGB_I2C(board.I2C(), cfg['lcd_columns'], cfg['lcd_rows'])
    try:
        for name, color in [('RED', [100, 0, 0]), ('GREEN', [0, 100, 0]), ('BLUE', [0, 0, 100])]:
            lcd.clear()
            lcd.color = color
            lcd.message = f'Demo 1 Project\nLCD test: {name}'
            print(f'the lcd should show text with {name.lower()} backlight.')
            time.sleep(2)
    finally:
        lcd.clear()
    print('the lcd writes completed. confirming text and colors visually.')


def prepare_motion(distance, angle_rad):
    # look for the arduino sketch in either of the supported folder layouts
    candidates = [HERE.parent / 'arduino' / 'Demo1Motion', HERE.parent / 'arduino']
    source = next((p for p in candidates if (p / 'Demo1Motion.ino').is_file()), None)
    if source is None:
        raise FileNotFoundError('expected arduino/Demo1Motion/Demo1Motion.ino beside the pi folder.')
    # prepare a separate sketch folder for this run
    destination = HERE / 'prepared_motion' / 'Demo1Motion'
    destination.mkdir(parents=True, exist_ok=True)
    # copy the sketch and both headers before changing the run settings
    for name in ('Demo1Motion.ino', 'MotionCore.h', 'RobotConfig.h'):
        shutil.copy2(source / name, destination / name)
    config = destination / 'RobotConfig.h'
    text = config.read_text()
    # change just the requested distance and angle in the copied robot config
    for name, value in [('RUN_DISTANCE_FT', distance), ('RUN_ANGLE_RAD', angle_rad)]:
        # format the values as float constants that the arduino code can use
        literal = f'{value:.9f}f'
        text, count = re.subn(r'(const float '+name+r'\s*=\s*)[^;]+;', lambda m: m[1] + literal + ';', text)
        # stop if the setting wasnt found exactly once so we dont prepare the wrong run
        if count != 1:
            raise ValueError(f'this expected exactly one {name} setting in RobotConfig.h.')
    config.write_text(text)
    return destination


def motion_task(turn):
    print('Task 3: turn, then drive' if turn else 'Task 2: drive straight')
    distance = number('Distance in feet (1 to 10): ', 1, 10)
    # a straight run uses zero turn angle
    angle = 0.0
    if turn:
        units = input('Angle units: d = degrees, r = radians [r]: ').strip().lower() or 'r'
        if units not in ('d', 'r'):
            raise ValueError('Use d or r for angle units.')
        angle = number('Signed turn (positive = left/CCW): ')
        # convert degrees to radians before putting the angle in the arduino config
        if units == 'd':
            angle = math.radians(angle)
    destination = prepare_motion(distance, angle)
    print(f'prepared {distance:g} ft, {angle:.6f} rad ({math.degrees(angle):.3f} degrees).')
    print(f'sketch: {destination / "Demo1Motion.ino"}')
    print('motor signs, encoder signs, wheel dimensions and controller gains come from  RobotConfig.h.')
    # if the upload tool isnt installed, keep the prepared files for the arduino ide
    if not shutil.which('arduino-cli'):
        print('arduino-cli isnt installed. you need to open the prepared sketch in Arduino IDE and upload it.')
        print('it starts automatically about 3 seconds after upload/reset. so no pi motion commands are needed.')
        return
    # show the connected boards so the port can be selected
    subprocess.run(['arduino-cli', 'board', 'list'], check=True)
    port = input('the arduino port from the list : ').strip()
    if not port:
        return
    fqbn = input('you need installed board configs: ').strip()
    if not fqbn:
        raise ValueError('you need the board configs to compile.')
    # compile the prepared sketch before asking whether to upload this run
    subprocess.run(['arduino-cli', 'compile', '--fqbn', fqbn, str(destination)], check=True)
    print('upload/resetting starts this movement automatically after about 3 seconds.')
    print('place the robot at its start position with a clear path before uploading.')
    # uploading starts the movement after reset, so check before sending it
    if input('upload this run now? [y/N]: ').strip().lower() != 'y':
        print('compiled sketch retained; nothing uploaded.')
        return
    subprocess.run(['arduino-cli', 'upload', '--port', port, '--fqbn', fqbn, str(destination)], check=True)
    print('the upload is finished. arduino performs the run autonomously;so  no further commands are sent.')
    print('you need to measure the final position physically. thsi firmware provides no completion telemetry to the Pi.')


# show the settings and check whether the saved calibration still matches
def status():
    from vision_common import load_config, load_calibration
    cfg = load_config(CONFIG)
    print(json.dumps(cfg, indent=2))
    try:
        load_calibration(cfg['calibration_file'], cfg)
        print('Saved calibration: compatible with configuration.')
    except (OSError, ValueError, KeyError) as exc:
        print(f'the saved calibration: {exc}')
    print('arduino upload tool:', shutil.which('arduino-cli') or 'not installed (Arduino IDE upload is available)')


# ask for the actual checkerboard dimensions before starting calibration
def calibration():
    print('inlcluded target: 9 x 6 INNER corners, nominal 20 mm squares.')
    cols = int(input('innner corners across [9]: ').strip() or '9')
    rows = int(input('inner corners down [6]: ').strip() or '6')
    square = number('measured square size in mm: ', .001)
    args = ['--cols', str(cols), '--rows', str(rows), '--square-mm', str(square)]
    if input('replace an existing calibration? [y/N]: ').strip().lower() == 'y':
        args.append('--force')
    run_script('calibrate_camera.py', *args)


def main():
    parser = argparse.ArgumentParser(description="Demo 1 terminal control panel")
    parser.add_argument('--no-preview', action='store_true', help='disable all camera windows, including child scripts')
    args = parser.parse_args()
    # child scripts inherit this too, so all camera windows can be disabled together
    if args.no_preview:
        os.environ['DEMO1_PREVIEW'] = '0'
    while True:
        print('''
Demo 1 Project
  1  task 1: marker angle demo on physical LCD
  2  task 2: prepare/upload a straight-distance run
  3  task 3: prepare/upload a turn-and-distance run
  4  test camera connection and frame capture (no calibration/LCD needed)
  5  test ArUco detection only (no calibration/LCD needed)
  6  test calibrated marker angle in terminal (no LCD needed)
  7  test LCD text and backlight (no camera needed)
  8  calibrate camera once / intentionally recalibrate
  9  show settings and calibration status
  v  CHECK ANGLE ACCURACY with a tape measure (run after calibrating)
  0  leave
''')
        try:
            choice = input('select an option: ').strip()
            if choice == '0':
                return
            # match each menu number to the function or script it should run
            actions = {'1': lambda: run_script('marker_angle.py'),
                       '2': lambda: motion_task(False), '3': lambda: motion_task(True),
                       '4': lambda: camera_test('camera'), '5': lambda: camera_test('markers'),
                       '6': lambda: camera_test('angle'), '7': lcd_test,
                       '8': calibration, '9': status,
                       'v': lambda: run_script('verify_angle.py'), 'V': lambda: run_script('verify_angle.py')}
            if choice not in actions:
                print('choose one of the listed numbers.')
                continue
            actions[choice]()
        except EOFError:
            return
        except KeyboardInterrupt:
            print('\nstopped. Returning to project menu.')
        # show the problem and let the menu come back for another try
        except Exception as exc:
            print(f'couldnt complete this option: {exc}')


if __name__ == '__main__':
    main()
