
# this gives us a live camera window
import os
import cv2
import numpy as np


# this handles the live camera window for the other camera scripts
class CameraPreview:
    def __init__(self, title="Demo 1 Camera"):
        self.stopped = False
        self.closed = False
        self.root = None
        self.enabled = False
        # allow preview to be turned off for all the scripts using the same setting
        if os.environ.get('DEMO1_PREVIEW', 'auto').lower() in ('0', 'off', 'false'):
            return
        # if theres no desktop display, keep going without trying to open a window
        if not (os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY')):
            print('theres not a desktop display but now were continuing without camera preview.', flush=True)
            return
        try:
            # use tkinter for the preview window so it doesnt need the opencv window functions
            import tkinter as tk
            self.tk = tk
            self.root = tk.Tk()
        except Exception as exc:
            print(f'the camera preview  is unavailable ({exc}); so were continuing without a window.', flush=True)
            return
        self.enabled = True
        self.root.title(title)
        self.label = tk.Label(self.root)
        self.label.pack()
        tk.Label(self.root, text="Q / Esc / close window: stop this camera mode").pack()
        self.stopped = False
        self.closed = False
        self.photo = None
        # closing the window or pressing q or escape asks the camera loop to stop
        self.root.protocol("WM_DELETE_WINDOW", self.stop)
        for key in ("q", "Q", "<Escape>"):
            self.root.bind(key, self.stop)

    # set the flag here, then let the main loop handle stoping and cleanup
    def stop(self, event=None):
        self.stopped = True

    # return false when the script should stop showing frames
    def show(self, frame, lines=(), corners=None, ids=None):
        if self.stopped or self.closed:
            return False
        if not self.enabled:
            return True
        # draw on a copy so the original camera image stays available
        canvas = frame.copy()
        if corners is not None and ids is not None:
            # outline each detected marker and put its id next to it
            for points, marker_id in zip(corners, ids.flatten()):
                polygon = np.asarray(points).reshape(4, 2).round().astype(np.int32)
                cv2.polylines(canvas, [polygon], True, (0, 255, 0), 2)
                x, y = polygon[0]
                cv2.putText(canvas, f"ID {int(marker_id)}", (int(x), max(15, int(y)-8)),
                            cv2.FONT_HERSHEY_SIMPLEX, .5, (0, 255, 0), 2)
        # shrink wide images to fit the window while keeping the same proportions
        if canvas.shape[1] > 960:
            canvas = cv2.resize(canvas, (960, round(canvas.shape[0] * 960 / canvas.shape[1])))
        # put the status text on a dark background so its easier to read
        if lines:
            cv2.rectangle(canvas, (0, 0), (canvas.shape[1], 28 * len(lines) + 8), (0, 0, 0), -1)
            for i, line in enumerate(lines):
                cv2.putText(canvas, str(line), (10, 25 + 28*i), cv2.FONT_HERSHEY_SIMPLEX,
                            .55, (255, 255, 255), 1)
        # opencv uses blue green red, but the preview image needs red green blue
        rgb = cv2.cvtColor(canvas, cv2.COLOR_BGR2RGB)
        h, w = rgb.shape[:2]
        # send the image directly to tkinter as bytes instead of saving a picture each frame
        ppm = f"P6\n{w} {h}\n255\n".encode("ascii") + rgb.tobytes()
        self.photo = self.tk.PhotoImage(data=ppm, format="PPM")
        self.label.configure(image=self.photo)
        # let the window redraw and process keys or the close button
        self.root.update_idletasks()
        self.root.update()
        return not self.stopped

    # only destroy the window once, even if cleanup gets called again
    def close(self):
        if not self.closed:
            self.closed = True
            if self.root is not None:
                self.root.destroy()
