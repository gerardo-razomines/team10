function [data,meta]=capture_robot_step(test,port,angleDeg,distFt)
% Read-only serial capture. Opening the port may RESET/START the Arduino.
% Examples: capture_robot_step('forward','COM6'); capture_robot_step('motion','COM6')
% Close Serial Monitor first. There are NO write/start/stop commands here.
if nargin<1,test='forward';end
if nargin<2 || isempty(port),error('Specify the actual port, e.g. capture_robot_step(''forward'',''COM6'').');end
root=fileparts(mfilename('fullpath'));settings=design_robot_controllers('settings');
% For a motion overlay, specify the target actually uploaded, e.g.
% capture_robot_step('motion','COM6',0,9). Defaults are 180 degrees, 1 foot.
% Target values record metadata only. They NEVER command the Arduino.
if nargin>=3 && ~isempty(angleDeg),settings.target_angle_deg=angleDeg;settings.TARGET_ANGLE=angleDeg;end
if nargin>=4 && ~isempty(distFt),settings.TARGET_DIST_FT=distFt;end
switch lower(test)
 case 'forward',ncol=7;mode=0;seconds=8;outfile='robotStep_forward.mat';
 case 'rotate',ncol=7;mode=1;seconds=8;outfile='robotStep_rotate.mat';
 case 'motion',ncol=10;mode=[];seconds=65;outfile='motionLog.mat';
 case 'sign',ncol=3;mode=2;seconds=8;outfile='robotSign.mat';
 case 'encoder',ncol=3;mode=3;seconds=25;outfile='robotEncoderCheck.mat';
 otherwise,error('Use forward, rotate, motion, sign, or encoder.');
end
s=serialport(port,115200,'Timeout',0.2);
cleanup=onCleanup(@() delete(s)); %#ok<NASGU>
configureTerminator(s,'LF');
% Do not flush here: startup CONFIG may already have arrived during port opening.
meta=struct('test',lower(test),'port',port,'settings',settings,'headers',{{}}, ...
 'terminal','','validated',false,'step_mode',[],'hardware_config',struct(),'created',datestr(now,30));
data=zeros(0,ncol);pending='';clock=tic;
fprintf('Port opened. Robot may reset/start now; recording without sending commands.\n');
while toc(clock)<seconds
 n=s.NumBytesAvailable;
 if n==0,pause(.002);continue;end
 pending=[pending char(read(s,n,'uint8'))]; %#ok<AGROW>
 lf=find(pending==char(10),1);
 while ~isempty(lf)
  line=strtrim(pending(1:lf-1));pending=pending(lf+1:end);
  if ~isempty(line)&&line(1)=='#'
   fprintf('%s\n',line);meta.headers{end+1}=line;
   if strncmp(line,'# CONFIG ',9)
    pairs=regexp(line,'(\w+)=([-+\d.eE]+)','tokens');
    for j=1:numel(pairs),meta.hardware_config.(pairs{j}{1})=str2double(pairs{j}{2});end
   end
   q=regexp(line,'^# STEP_MODE=(\d+)$','tokens','once');
   if ~isempty(q),meta.step_mode=str2double(q{1});end
   if strncmp(line,'# RESULT ',9),meta.terminal=line;end
  elseif ~isempty(line)
   v=sscanf(line,'%f');
   if numel(v)==ncol&&all(isfinite(v)),data(end+1,:)=v(:)';end %#ok<AGROW>
  end
  lf=find(pending==char(10),1);
 end
 if ~isempty(meta.terminal),break;end
end
meta.complete=~isempty(meta.terminal);
meta.passed=meta.complete && isempty(strfind(meta.terminal,'FAULT'));
save(fullfile(root,outfile),'data','meta','settings');
assert(~isempty(data),'No data rows. Check port, sketch and test mode.');
assert(all(diff(data(:,1))>0),'Repeated timestamps: board reset during capture. Reject this recording.');
assert(meta.complete,'No final RESULT. Incomplete recording saved for diagnosis, not identification.');
assert(meta.passed,['Robot reported a fault. Recording saved for diagnosis: ' meta.terminal]);
if ~isempty(mode),assert(isequal(meta.step_mode,mode),'Wrong StepID mode or missed startup header.');end
c=meta.hardware_config;
assert(isfield(c,'r')&&isfield(c,'d')&&isfield(c,'cpr')&&isfield(c,'batt'), ...
    'CONFIG header missing. Restart capture to record the complete startup.');
b=struct('wheel_radius_m',c.r,'wheel_spacing_m',c.d,'counts_per_rev',c.cpr, ...
 'battery_v',c.batt,'right_idx',c.right,'left_idx',c.left, ...
 'motor_sign',[c.motor0 c.motor1],'encoder_sign',[c.enc0 c.enc1]);
check_robot_settings(settings,b);
meta.validated=true;save(fullfile(root,outfile),'data','meta','settings');
fprintf('Saved %d rows: %s\n',size(data,1),outfile);
figure;
if ncol==10
 plot(data(:,7),data(:,8),'.-');axis equal;grid on;xlabel('x (in)');ylabel('y (in)');
 title('Experimental encoder odometry (verify on the floor)');
elseif ncol==7
 subplot(2,1,1);plot(data(:,1),data(:,4));ylabel('Forward speed (m/s)');grid on;
 subplot(2,1,2);plot(data(:,1),data(:,5));ylabel('Turn rate (rad/s)');xlabel('Time (s)');grid on;
else
 plot(data(:,1),data(:,2:3));legend('Right counts','Left counts');grid on;xlabel('Time (s)');
end
end

function check_robot_settings(a,b)
% Compare the geometry/sign/voltage convention of a capture/model and firmware.
fields={'wheel_radius_m','wheel_spacing_m','counts_per_rev','battery_v', ...
    'right_idx','left_idx','motor_sign','encoder_sign'};
for i=1:numel(fields)
    f=fields{i};assert(isfield(a,f)&&isfield(b,f),['Missing metadata: ' f]);
    x=a.(f);y=b.(f);
    assert(isequal(size(x),size(y))&&all(abs(x(:)-y(:))<=1e-5*max(1,max(abs(x(:))))), ...
        ['Settings changed since capture: ' f '. Recollect step data.']);
end
end
