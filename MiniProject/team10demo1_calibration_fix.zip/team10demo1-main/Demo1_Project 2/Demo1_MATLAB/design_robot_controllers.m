function result=design_robot_controllers(angleDeg,distFt)
% Simulate the CURRENT Arduino gains. Proposed inner gains are printed only.
% No Arduino headers, sources or working gains are overwritten.
% Run design_robot_controllers(180,1) for one simulation, or use any test target.
% Units: DEGREES and FEET. This function does not connect to the robot.
% Internal settings access used by capture/identify, without running a simulation.
if nargin>=1 && ischar(angleDeg) && strcmp(angleDeg,'settings')
    result=robot_config();return;
end
s=robot_config();
if nargin<1 || isempty(angleDeg),angleDeg=s.target_angle_deg;end
if nargin<2 || isempty(distFt),distFt=s.TARGET_DIST_FT;end
[plant,identified]=get_robot_plant(s);
if identified
 fprintf('Using fitted step-response plant. Controller gains remain those in RobotConfig.h.\n');
else
 fprintf('ILLUSTRATIVE SIMULATION: no experimental robotModel.mat.\n');
 fprintf('Plant gains copied from header; sigma=8 /s and motor dead zone=0.3 V are assumptions.\n');
end
fprintf('Radius=%.6f m; track=%.6f m; heading tolerance=%.6f rad.\n',s.WHEEL_R,s.WHEEL_D,s.PHI_TOL);
pole=30;
proposed=[(pole/plant.sigma_rho-1)/plant.K_rho,(pole/plant.sigma_phi-1)/plant.K_phi];
fprintf('Current KPV_RHO=%.4f, KPV_PHI=%.4f\n',s.KPV_RHO,s.KPV_PHI);
if all(proposed>=0)
 fprintf('Analytical candidates for nominal pole 30 /s: %.4f, %.4f (NOT applied).\n',proposed);
else
 fprintf('Pole 30 /s requires a negative P gain for this fit; review the bandwidth/model.\n');
end
result=simulate_robot(s,angleDeg,distFt,plant);result.model_identified=identified;
if result.success,status='SUCCESS';else,status=['FAULT: ' result.reason];end
fprintf('Simulation %s at %.3f s. Model endpoint error=%.3f in; odometry error=%.3f in.\n', ...
 status,result.finish_s,result.model_endpoint_error_in,result.odom_endpoint_error_in);
root=fileparts(mfilename('fullpath'));save(fullfile(root,'simulationRun.mat'),'result');
L=result.log;t=L(:,1);
figure('Name','Demo 1 simulation');
subplot(3,1,1);plot(t,L(:,3)*39.37007874,'--',t,L(:,4)*39.37007874,'-');
ylabel('Distance (in)');legend('Reference','Encoder estimate');grid on;title(status);
subplot(3,1,2);plot(t,L(:,5)*180/pi,'--',t,L(:,6)*180/pi,'-');
ylabel('Heading (deg)');legend('Reference','Encoder estimate');grid on;
subplot(3,1,3);plot(t,L(:,9:10));ylabel('Motor voltage (V)');xlabel('Time (s)');legend('Right','Left');grid on;
figure('Name','Robot path');plot(result.truth(:,3)*39.37007874,result.truth(:,4)*39.37007874,'-');hold on;
plot(L(:,7),L(:,8),'--');plot(distFt*12*cosd(angleDeg),distFt*12*sind(angleDeg),'rx');
legend('Modeled physical path','Encoder estimate','Target');axis equal;grid on;
xlabel('x (in)');ylabel('y (in)');title('Simulation: compare physical accuracy separately on the floor');
% Overlay only captures saved with this workflow and the same requested target.
logfile=fullfile(root,'motionLog.mat');
if isfile(logfile)
 q=load(logfile);
 try
  assert(isfield(q.meta,'validated')&&q.meta.validated&&q.meta.complete&&q.meta.passed,'Incomplete/failed experimental run.');
  check_robot_settings(s,q.settings);
  assert(abs(q.settings.target_angle_deg-angleDeg)<1e-5 && abs(q.settings.TARGET_DIST_FT-distFt)<1e-5, ...
   'Recorded source target differs from simulation target.');
  plot(q.data(:,7),q.data(:,8),'.');legend('Modeled physical path','Encoder estimate','Target','Experimental encoder estimate');
 catch err
  warning('Experimental overlay skipped: %s',err.message);
 end
end
end

function s=robot_config()
% Settings copied from the latest uploaded Demo1_Motion.zip.
% This is the ONE settings block used by all three MATLAB files.
% If Arduino gains/geometry change later, update the corresponding values here.
% No Arduino files are read, edited, regenerated or uploaded by this package.
s=struct;
s.RIGHT_IDX=1;
s.LEFT_IDX=0;
s.WHEEL_R=0.074895;
s.WHEEL_D=0.3683;
s.COUNTS_PER_REV=3200.0;
s.BATTERY_V=7.8;
s.K_RHO=0.0566;
s.K_PHI=0.307;
s.KPV_RHO=48.6;
s.KPV_PHI=8.96;
s.KP_RHO=6.0;
s.KI_RHO=3.0;
s.KP_PHI=6.0;
s.KI_PHI=3.0;
s.V_MAX=0.35;
s.A_MAX=0.4;
s.W_MAX=1.5;
s.AW_MAX=2.0;
s.RHO_DOT_CMD_MAX=0.5;
s.PHI_DOT_CMD_MAX=2.5;
s.I_RHO_MAX=0.05;
s.I_PHI_MAX=0.1;
s.RHO_TOL=0.002;
s.PHI_TOL=0.0036;
s.RATE_TOL_RHO=0.01;
s.RATE_TOL_PHI=0.03;
s.STALL_VOLTAGE=1.5;
s.TS_US=10000;
s.SETTLE_MS=250;
s.VERIFY_STOP_MS=350;
s.TIMEOUT_MS=5000;
s.START_DELAY_MS=1000;
s.PAUSE_MS=300;
s.MAX_RUN_MS=55000;
s.STALL_MS=2000;
s.MOTOR_SIGN=[-1 1];s.ENC_SIGN=[-1 1];
s.TARGET_ANGLE=180;s.ANGLE_IN_DEGREES=true;s.TARGET_DIST_FT=1;
s.target_angle_deg=s.TARGET_ANGLE;s.Ts=s.TS_US*1e-6;
s.wheel_radius_m=s.WHEEL_R;s.wheel_spacing_m=s.WHEEL_D;
s.counts_per_rev=s.COUNTS_PER_REV;s.battery_v=s.BATTERY_V;
s.right_idx=s.RIGHT_IDX;s.left_idx=s.LEFT_IDX;
s.motor_sign=s.MOTOR_SIGN;s.encoder_sign=s.ENC_SIGN;
end

function [plant,identified]=get_robot_plant(s)
% Read a measured model when available. Otherwise mark all plant values as assumptions.
root=fileparts(mfilename('fullpath'));path=fullfile(root,'robotModel.mat');identified=false;
plant=struct('K_rho',s.K_RHO,'K_phi',s.K_PHI,'sigma_rho',8,'sigma_phi',8, ...
 'radius_m',s.WHEEL_R,'track_m',s.WHEEL_D,'deadzone_v',.3);
if isfile(path)
 m=load(path);assert(isfield(m,'settings'),'Old robotModel.mat: archive and re-identify.');
 check_robot_settings(s,m.settings);
 keys={'K_rho','K_phi','sigma_rho','sigma_phi'};
 for k=1:numel(keys)
  v=m.(keys{k});assert(isscalar(v)&&isfinite(v)&&v>0,'Invalid measured model.');
  plant.(keys{k})=v;
 end
 identified=true;
end
end

function check_robot_settings(a,b)
% Compare the geometry/sign/voltage convention of a capture/model and firmware.
fields={'wheel_radius_m','wheel_spacing_m','counts_per_rev','battery_v', ...
    'right_idx','left_idx','motor_sign','encoder_sign'};
for i=1:numel(fields)
    f=fields{i};assert(isfield(a,f)&&isfield(b,f),['Missing metadata: ' f]);
    x=a.(f);y=b.(f);
    assert(isequal(size(x),size(y))&&all(abs(x(:)-y(:))<=1e-5*max(1,max(abs(x(:))))), ...
        ['Settings changed since capture: ' f '. Recollect step data.']);
end
end

function result=simulate_robot(s,angleDeg,distFt,plant)
% Numerical model of the supplied firmware's control/supervisor logic.
% Controller settings come from RobotConfig.h. Plant parameters are assumptions
% unless fitted to complete experimental step captures. No hardware commands.
if nargin<2 || isempty(angleDeg),angleDeg=s.target_angle_deg;end
if nargin<3 || isempty(distFt),distFt=s.TARGET_DIST_FT;end
if nargin<4 || isempty(plant)
    plant=struct('K_rho',s.K_RHO,'K_phi',s.K_PHI,'sigma_rho',8,'sigma_phi',8);
end
if ~isfield(plant,'radius_m'),plant.radius_m=s.WHEEL_R;end
if ~isfield(plant,'track_m'),plant.track_m=s.WHEEL_D;end
if ~isfield(plant,'deadzone_v'),plant.deadzone_v=0.3;end
assert(all(isfinite([angleDeg,distFt])) && distFt>=0 && distFt<=10 && abs(angleDeg)<=720);
assert(all([plant.K_rho plant.K_phi plant.sigma_rho plant.sigma_phi plant.radius_m plant.track_m]>0));
assert(plant.deadzone_v>=0 && plant.deadzone_v<s.BATTERY_V);
assert(s.Ts>0 && all([s.V_MAX,s.A_MAX,s.W_MAX,s.AW_MAX]>0));
M2IN=39.37007874;targetR=distFt*.3048;targetP=angleDeg*pi/180;
tp=profile(targetP,s.W_MAX,s.AW_MAX);dp=profile(targetR,s.V_MAX,s.A_MAX);
% States follow MotionTypes.h: WAIT TURN PAUSE DRIVE VERIFY_STOP DONE FAULT.
state=0;stateMs=0;runMs=0;settleActive=false;settleMs=0;reason='NONE';
rho=0;phi=0;rhod=0;phid=0;ox=0;oy=0;cr=0;cl=0;
tr=0;th=0;tv=0;tw=0;tx=0;ty=0; % modeled true state, separate from encoder estimate
refR=0;refP=0;ffR=0;ffP=0;ir=0;ip=0;
activityR=0;activityL=0;lastR=0;lastL=0;vr=0;vl=0;
N=ceil((s.START_DELAY_MS+s.MAX_RUN_MS+1000)/(1000*s.Ts));
L=zeros(N,10);truth=zeros(N,6);phases=[0 0];
worst=(tp.T+dp.T)*1000+2*s.TIMEOUT_MS+s.PAUSE_MS+s.VERIFY_STOP_MS+2*s.SETTLE_MS;
if worst>s.MAX_RUN_MS,fail('TARGET_EXCEEDS_TIME_BUDGET',0);end
for k=1:N
    t=k*s.Ts;now=round(t*1000);
    % Advance the approximate motor plant using the preceding PWM command.
    nsub=max(1,ceil(s.Ts/.001));h=s.Ts/nsub;
    veR=sign(vr)*max(abs(vr)-plant.deadzone_v,0);
    veL=sign(vl)*max(abs(vl)-plant.deadzone_v,0);
    for j=1:nsub
        tv=tv+h*plant.sigma_rho*(plant.K_rho*(veR+veL)-tv);
        tw=tw+h*plant.sigma_phi*(plant.K_phi*(veR-veL)-tw);
        tx=tx+h*tv*cos(th);ty=ty+h*tv*sin(th);
        tr=tr+h*tv;th=th+h*tw;
    end
    % Same A-CHANGE / +/-2 count scale; signs assumed verified on the robot.
    nr=2*round((tr+th*plant.track_m/2)/plant.radius_m*s.COUNTS_PER_REV/(4*pi));
    nl=2*round((tr-th*plant.track_m/2)/plant.radius_m*s.COUNTS_PER_REV/(4*pi));
    dr=s.WHEEL_R*2*pi/s.COUNTS_PER_REV*(nr-cr);
    dl=s.WHEEL_R*2*pi/s.COUNTS_PER_REV*(nl-cl);
    ds=(dr+dl)/2;da=(dr-dl)/s.WHEEL_D;
    ox=ox+ds*cos(phi+da/2);oy=oy+ds*sin(phi+da/2);
    rho=s.WHEEL_R*2*pi/s.COUNTS_PER_REV*(nr+nl)/2;
    phi=s.WHEEL_R*2*pi/s.COUNTS_PER_REV*(nr-nl)/s.WHEEL_D;
    rhod=ds/s.Ts;phid=da/s.Ts;cr=nr;cl=nl;
    if ~ismember(state,[0 5 6]) && now-runMs>=s.MAX_RUN_MS,fail('RUN_TIME_LIMIT',now);end
    ts=(now-stateMs)*.001;
    switch state
        case 0
            if now-stateMs>=s.START_DELAY_MS
                runMs=now;
                if abs(targetP)>1e-4,enter(1,now);else,enter(3,now);end
            end
        case 1
            [refP,ffP]=evaluate(tp,ts);refR=0;ffR=0;
            if ts>=tp.T
                if settled(0,targetP,now),enter(2,now);
                elseif ts*1000>=tp.T*1000+s.TIMEOUT_MS
                    enter(2,now); % intentionally matches supplied firmware's timeout continuation
                end
            end
        case 2
            refP=targetP;refR=0;ffP=0;ffR=0;
            if ~at_target(0,targetP),settleActive=false;end
            if now-stateMs>=s.PAUSE_MS && settled(0,targetP,now)
                ir=0;enter(3,now);
            elseif now-stateMs>s.PAUSE_MS+s.TIMEOUT_MS
                ir=0;enter(3,now); % supplied firmware also continues here
            end
        case 3
            [refR,ffR]=evaluate(dp,ts);refP=targetP;ffP=0;
            if ts>=dp.T
                if settled(targetR,targetP,now),enter(4,now);
                elseif ts*1000>=dp.T*1000+s.TIMEOUT_MS,fail('DRIVE_NOT_SETTLED',now);end
            end
        case 4
            if now-stateMs>=s.VERIFY_STOP_MS
                if at_target(targetR,targetP),enter(5,now);
                else,fail('STOP_DRIFT_OR_MOTION',now);end
            end
    end
    active=ismember(state,[1 2 3]);vr=0;vl=0;
    if active
        er=refR-rho;ep=refP-phi;
        rd0=ffR+s.KP_RHO*er+s.KI_RHO*ir;
        pd0=ffP+s.KP_PHI*ep+s.KI_PHI*ip;
        rd=clip(rd0,-s.RHO_DOT_CMD_MAX,s.RHO_DOT_CMD_MAX);
        pd=clip(pd0,-s.PHI_DOT_CMD_MAX,s.PHI_DOT_CMD_MAX);
        vb=rd/s.K_RHO+s.KPV_RHO*(rd-rhod);
        dv=pd/s.K_PHI+s.KPV_PHI*(pd-phid);
        vr=(vb+dv)/2;vl=(vb-dv)/2;
        largest=max(abs([vr vl]));saturated=largest>s.BATTERY_V;
        if saturated,vr=vr*s.BATTERY_V/largest;vl=vl*s.BATTERY_V/largest;end
        if (~saturated && rd==rd0) || er*ir<0,ir=clip(ir+er*s.Ts,-s.I_RHO_MAX,s.I_RHO_MAX);end
        if (~saturated && pd==pd0) || ep*ip<0,ip=clip(ip+ep*s.Ts,-s.I_PHI_MAX,s.I_PHI_MAX);end
        if cr~=activityR,activityR=cr;lastR=now;end
        if cl~=activityL,activityL=cl;lastL=now;end
        if abs(vr)<s.STALL_VOLTAGE,lastR=now;end
        if abs(vl)<s.STALL_VOLTAGE,lastL=now;end
        if now-lastR>s.STALL_MS,fail('RIGHT_NO_ENCODER_PROGRESS',now);
        elseif now-lastL>s.STALL_MS,fail('LEFT_NO_ENCODER_PROGRESS',now);end
    else
        lastR=now;lastL=now;
    end
    if state==6 || ~active,vr=0;vl=0;end
    vr=quantize_voltage(vr,s.BATTERY_V);vl=quantize_voltage(vl,s.BATTERY_V);
    % Exactly the Arduino motion log column order and displayed units.
    L(k,:)=[t state refR rho refP phi ox*M2IN oy*M2IN vr vl];
    truth(k,:)=[tr th tx ty tv tw];
    if ismember(state,[5 6]),break;end
end
if ~ismember(state,[5 6]),reason='SIMULATION_HORIZON';end
result=struct('state',state,'success',state==5,'reason',reason, ...
    'finish_s',L(k,1),'angle_deg',angleDeg,'distance_ft',distFt, ...
    'log',L(1:k,:),'truth',truth(1:k,:),'phases',phases,'settings',s,'plant',plant);
result.odom_endpoint_error_in=hypot(ox-targetR*cos(targetP),oy-targetR*sin(targetP))*M2IN;
result.model_endpoint_error_in=hypot(tx-targetR*cos(targetP),ty-targetR*sin(targetP))*M2IN;
result.distance_error_in=(rho-targetR)*M2IN;
result.heading_error_deg=(phi-targetP)*180/pi;
    function enter(next,nowMs)
        state=next;stateMs=nowMs;settleActive=false;
        phases(end+1,:)=[nowMs*.001 next];
    end
    function fail(msg,nowMs)
        reason=msg;enter(6,nowMs);
    end
    function yes=at_target(r,p)
        yes=abs(r-rho)<=s.RHO_TOL && abs(p-phi)<=s.PHI_TOL && ...
            abs(rhod)<=s.RATE_TOL_RHO && abs(phid)<=s.RATE_TOL_PHI;
    end
    function yes=settled(r,p,nowMs)
        if ~at_target(r,p),settleActive=false;yes=false;return;end
        if ~settleActive,settleActive=true;settleMs=nowMs;end
        yes=nowMs-settleMs>=s.SETTLE_MS;
    end
end
function y=clip(x,a,b),y=min(max(x,a),b);end
function v=quantize_voltage(v,b),v=sign(v)*round(255*abs(clip(v,-b,b))/b)*b/255;end
function p=profile(D,v,a)
p=struct('D',D,'a',a,'tA',v/a,'vp',v,'tC',0,'T',0);d=abs(D);
if a*p.tA^2>d,p.tA=sqrt(d/a);p.vp=a*p.tA;
else,p.tC=(d-a*p.tA^2)/v;end
p.T=2*p.tA+p.tC;
end
function [pos,vel]=evaluate(p,t)
d=0;v=0;
if t<=0
elseif t<p.tA,v=p.a*t;d=.5*p.a*t*t;
elseif t<p.tA+p.tC,v=p.vp;d=.5*p.a*p.tA^2+p.vp*(t-p.tA);
elseif t<p.T,tr=p.T-t;v=p.a*tr;d=abs(p.D)-.5*p.a*tr*tr;
else,d=abs(p.D);end
sgn=1;if p.D<0,sgn=-1;end
pos=sgn*d;vel=sgn*v;
end
