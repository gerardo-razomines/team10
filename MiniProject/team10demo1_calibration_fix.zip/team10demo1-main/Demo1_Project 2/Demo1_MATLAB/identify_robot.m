function model=identify_robot()
% Requires complete forward(mode 0) and rotation(mode 1) recordings.
root=fileparts(mfilename('fullpath'));settings=design_robot_controllers('settings');
f=load(fullfile(root,'robotStep_forward.mat'));r=load(fullfile(root,'robotStep_rotate.mat'));
validate(f,'forward',0);validate(r,'rotate',1);
[K_rho,sigma_rho,fi]=fit_step_model(f.data(:,1),f.data(:,2),f.data(:,4));
[K_phi,sigma_phi,ri]=fit_step_model(r.data(:,1),r.data(:,3),r.data(:,5));
save(fullfile(root,'robotModel.mat'),'K_rho','sigma_rho','K_phi','sigma_phi','settings','fi','ri');
model=struct('K_rho',K_rho,'sigma_rho',sigma_rho,'K_phi',K_phi,'sigma_phi',sigma_phi);
fprintf('Forward K=%.6f, sigma=%.3f /s, fit NRMSE=%.3f\n',K_rho,sigma_rho,fi.nrmse);
fprintf('Rotation K=%.6f, sigma=%.3f /s, fit NRMSE=%.3f\n',K_phi,sigma_phi,ri.nrmse);
fprintf('Saved robotModel.mat. Arduino gains were NOT changed.\n');
a=abs(f.data(:,2))>.1;b=abs(r.data(:,3))>.1;
fprintf('Coupling: rotation during forward=%.4f rad/s; translation during turn=%.4f m/s\n', ...
 mean(abs(f.data(a,5))),mean(abs(r.data(b,4))));
figure;
subplot(2,1,1);plot(f.data(:,1),f.data(:,4),'.',f.data(:,1),fi.predicted,'-');
ylabel('Forward speed (m/s)');legend('Experiment','Model');grid on;
subplot(2,1,2);plot(r.data(:,1),r.data(:,5),'.',r.data(:,1),ri.predicted,'-');
ylabel('Turn rate (rad/s)');xlabel('Time (s)');legend('Experiment','Model');grid on;
 function validate(q,name,mode)
  assert(isfield(q,'data')&&isfield(q,'meta')&&isfield(q,'settings'), ...
      'Old MAT format. Recapture with the supplied capture function.');
  assert(strcmp(q.meta.test,name)&&isequal(q.meta.step_mode,mode), 'Wrong StepID test.');
  assert(isfield(q.meta,'validated')&&q.meta.validated&&q.meta.complete&&q.meta.passed&&~isempty(strfind(q.meta.terminal,'STEP_COMPLETE')), ...
      'Capture failed or incomplete.');
  assert(size(q.data,2)==7,'Expected seven columns.');
  check_robot_settings(settings,q.settings);
 end
end

function check_robot_settings(a,b)
% Compare the geometry/sign/voltage convention of a capture/model and firmware.
fields={'wheel_radius_m','wheel_spacing_m','counts_per_rev','battery_v', ...
    'right_idx','left_idx','motor_sign','encoder_sign'};
for i=1:numel(fields)
    f=fields{i};assert(isfield(a,f)&&isfield(b,f),['Missing metadata: ' f]);
    x=a.(f);y=b.(f);
    assert(isequal(size(x),size(y))&&all(abs(x(:)-y(:))<=1e-5*max(1,max(abs(x(:))))), ...
        ['Settings changed since capture: ' f '. Recollect step data.']);
end
end

function [K,sigma,fit]=fit_step_model(t,u,y)
% Fit a positive first-order model to RECORDED input using base-MATLAB fminsearch.
% Uses the whole on/off response instead of accepting one noisy 63.2% crossing.
t=t(:);u=u(:);y=y(:);
assert(numel(t)>=20 && numel(u)==numel(t)&&numel(y)==numel(t));
assert(all(isfinite([t;u;y]))&&all(diff(t)>0),'Invalid/non-increasing samples.');
peak=max(abs(u));assert(peak>.1,'No input pulse found.');
on=find(abs(u)>.2*peak);assert(numel(on)>=5,'Too few pulse samples.');
assert(all(diff(on)==1),'Expected one contiguous step pulse.');
U=median(u(on));assert(U>0,'Expected positive forward/rotation pseudo-input. Check test/signs.');
pre=find(t<t(on(1)));assert(numel(pre)>=3,'Missing pre-step baseline.');
baseline=median(y(pre));yc=y-baseline;
tail=on(max(1,ceil(.7*numel(on))):end);steady=median(yc(tail));
assert(steady>1e-4,'No positive motor response. Check power, encoder signs and test selection.');
K0=steady/U;
ix=on(find(yc(on)>=.632*steady,1));
tau=.125;if ~isempty(ix),tau=max(t(ix)-t(on(1)),median(diff(t)));end
z0=log([K0,1/tau]);scale=max(sqrt(mean(yc.^2)),1e-6);
options=optimset('Display','off','MaxIter',1500,'MaxFunEvals',4000,'TolX',1e-7);
z=fminsearch(@objective,z0,options);K=exp(z(1));sigma=exp(z(2));
pred=response(K,sigma);nrmse=sqrt(mean((pred-yc).^2))/scale;
assert(all(isfinite([K sigma nrmse]))&&K>0&&sigma>0,'Nonphysical model fit.');
assert(nrmse<.5,'Poor first-order fit. Inspect the capture; do not use these gains.');
if nrmse>.2,warning('Model mismatch: normalized RMSE %.3f. Inspect the fit before use.',nrmse);end
fit=struct('predicted',pred+baseline,'nrmse',nrmse,'baseline',baseline,'input',u,'time',t);
 function loss=objective(zv)
  if any(~isfinite(zv))||any(abs(zv)>25),loss=1e20;return;end
  yp=response(exp(zv(1)),exp(zv(2)));
  loss=mean(((yp-yc)/scale).^2);
 end
 function yp=response(kg,sg)
  yp=zeros(size(t));yp(1)=yc(1);
  for j=2:numel(t)
   a=exp(-sg*(t(j)-t(j-1)));
   yp(j)=a*yp(j-1)+kg*(1-a)*u(j-1);
  end
 end
end
