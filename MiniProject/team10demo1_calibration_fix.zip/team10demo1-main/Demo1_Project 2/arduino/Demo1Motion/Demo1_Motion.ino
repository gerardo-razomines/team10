
/* EENG350 Demo 1 - Localization and Control (revised partner implementation).
   Tasks: straight drive (TARGET_ANGLE=0), or turn, then straight drive.
   Positive angle = left / counterclockwise. Distances entered in FEET.
   Edit robot_settings.m + run configure_robot for geometry/signs/gains.
   Pins are UNCHANGED. See RobotConfig.h / RUN_GUIDE.md.
   Terminal messages: # RESULT SUCCESS or # RESULT FAULT reason=...
   A timeout is a FAILURE: the robot stops and never advances to the next task.
   Encoder SUCCESS still requires a tape-measure/floor check; slip is unobserved.
   No runtime commands, I2C, or computer-vision dependencies are introduced.
*/

#include "RobotConfig.h"
#include "RobotIO.h"
#include "MotionTypes.h"

// ===== EDIT THESE TWO TARGETS BEFORE UPLOADING =====
const float TARGET_ANGLE=180.0f;
const bool ANGLE_IN_DEGREES=true; // false: TARGET_ANGLE is in radians
const float TARGET_DIST_FT=1.0f;  // demo: 1..10 ft; 0 allowed for turn calibration
// =================================================
const float FT_TO_M=0.3048f, M_TO_IN=39.37007874f;
Profile turnProf,driveProf;
State state=WAIT;
float phi_target=0,dist_target=0;
float rho_ref=0,phi_ref=0,rho_ff=0,phi_ff=0;
float I_rho=0,I_phi=0;
uint32_t lastUs=0,t0=0,state_ms=0,run_ms=0,lastLogMs=0,settle_ms=0;
bool settle_active=false,resultPrinted=false;
const char* faultReason="NONE";
long activityR=0,activityL=0;
uint32_t lastActivityR=0,lastActivityL=0;

void makeProfile(Profile &p,float D,float vmax,float amax){
  float d=fabs(D);p.D=D;p.a=amax;p.tA=vmax/amax;
  if(amax*p.tA*p.tA>d){p.tA=sqrt(d/amax);p.vp=amax*p.tA;p.tC=0;}
  else{p.vp=vmax;p.tC=(d-amax*p.tA*p.tA)/vmax;}
  p.T=2*p.tA+p.tC;
}
void evalProfile(const Profile &p,float t,float &pos,float &vel){
  float d=0,v=0,sign=p.D>=0?1.0f:-1.0f;
  if(t<=0){}
  else if(t<p.tA){v=p.a*t;d=0.5f*p.a*t*t;}
  else if(t<p.tA+p.tC){v=p.vp;d=0.5f*p.a*p.tA*p.tA+p.vp*(t-p.tA);}
  else if(t<p.T){float tr=p.T-t;v=p.a*tr;d=fabs(p.D)-0.5f*p.a*tr*tr;}
  else{d=fabs(p.D);}
  pos=sign*d;vel=sign*v;
}
void enterState(State next){state=next;state_ms=millis();settle_active=false;}
void fail(const char* reason){
  faultReason=reason;enterState(FAULT);stopMotors();digitalWrite(enablePin,LOW);
}
bool atRestAndTarget(float rhoGoal,float phiGoal){
  return fabs(rhoGoal-pose.rho)<=RHO_TOL && fabs(phiGoal-pose.phi)<=PHI_TOL &&
         fabs(pose.rhod)<=RATE_TOL_RHO && fabs(pose.phid)<=RATE_TOL_PHI;
}
bool settledBoth(float rhoGoal,float phiGoal,uint32_t now){
  if(!atRestAndTarget(rhoGoal,phiGoal)){settle_active=false;return false;}
  if(!settle_active){settle_active=true;settle_ms=now;}
  return (uint32_t)(now-settle_ms)>=SETTLE_MS;
}
void reportResult(uint32_t now){
  if(resultPrinted)return;resultPrinted=true;
  if(state==DONE)Serial.print(F("# RESULT SUCCESS"));
  else{Serial.print(F("# RESULT FAULT reason="));Serial.print(faultReason);}
  Serial.print(F(" elapsed_s="));Serial.print((now-t0)/1000.0f,3);
  Serial.print(F(" rho_in="));Serial.print(pose.rho*M_TO_IN,3);
  Serial.print(F(" heading_deg="));Serial.print(pose.phi*180.0f/PI,3);
  Serial.print(F(" x_in="));Serial.print(pose.x*M_TO_IN,3);
  Serial.print(F(" y_in="));Serial.print(pose.y*M_TO_IN,3);
  float gx=dist_target*cos(phi_target),gy=dist_target*sin(phi_target);
  Serial.print(F(" odom_endpoint_error_in="));
  Serial.println(hypot(pose.x-gx,pose.y-gy)*M_TO_IN,3);
}
void setup(){
  initRobot();Serial.begin(115200);printConfig();
  phi_target=ANGLE_IN_DEGREES?TARGET_ANGLE*PI/180.0f:TARGET_ANGLE;
  dist_target=TARGET_DIST_FT*FT_TO_M;
  t0=millis();run_ms=t0;lastLogMs=t0;enterState(WAIT);
  lastActivityR=t0;lastActivityL=t0;
  if(!configValid() || !isfinite(phi_target) || !isfinite(dist_target) ||
     TARGET_DIST_FT<0 || TARGET_DIST_FT>10 || fabs(phi_target)>4*PI ||
     K_RHO<=0 || K_PHI<=0 || !isfinite(K_RHO) || !isfinite(K_PHI)){
    fail("INVALID_CONFIG_OR_TARGET");
  }else{
    makeProfile(turnProf,phi_target,W_MAX,AW_MAX);
    makeProfile(driveProf,dist_target,V_MAX,A_MAX);
    float worst_ms=(turnProf.T+driveProf.T)*1000+2*TIMEOUT_MS+PAUSE_MS+VERIFY_STOP_MS+2*SETTLE_MS;
    if(worst_ms>MAX_RUN_MS)fail("TARGET_EXCEEDS_TIME_BUDGET");
  }
  Serial.println(F("# t\tstate\trho_ref\trho\tphi_ref\tphi\tx_in\ty_in\tVR\tVL"));
  Serial.println(F("# STATES 0=WAIT 1=TURN 2=PAUSE 3=DRIVE 4=VERIFY_STOP 5=DONE 6=FAULT"));
  lastUs=micros();
}
void loop(){
  uint32_t nowUs=micros(),elapsedUs=(uint32_t)(nowUs-lastUs);
  if(elapsedUs<TS_US)return;
  lastUs=nowUs;float dt=elapsedUs*1e-6f;uint32_t now=millis();
  // Use actual sample duration; do not run short catch-up iterations.
  if(elapsedUs>3*TS_US && state!=WAIT && state!=DONE && state!=FAULT)fail("CONTROL_TIMING_OVERRUN");
  readPose(dt);
  if(state!=WAIT && state!=DONE && state!=FAULT && (uint32_t)(now-run_ms)>=MAX_RUN_MS)fail("RUN_TIME_LIMIT");
  float ts=(uint32_t)(now-state_ms)*0.001f;
  switch(state){
    case WAIT:
      if((uint32_t)(now-state_ms)>=START_DELAY_MS){
        run_ms=now;
        if(fabs(phi_target)>1e-4f)enterState(TURN);else enterState(DRIVE);
      }break;
    case TURN:
      evalProfile(turnProf,ts,phi_ref,phi_ff);rho_ref=0;rho_ff=0;
      if(ts>=turnProf.T){
        if(settledBoth(0,phi_target,now))enterState(PAUSE);
        else if(ts*1000>=turnProf.T*1000+TIMEOUT_MS)enterState(PAUSE); // close enough: keep going instead of aborting the run
      }break;
    case PAUSE:
      phi_ref=phi_target;rho_ref=0;phi_ff=0;rho_ff=0;
      // Recheck both axes before allowing translation.
      if(!atRestAndTarget(0,phi_target)){settle_active=false;}
      if((uint32_t)(now-state_ms)>=PAUSE_MS && settledBoth(0,phi_target,now)){
        I_rho=0;enterState(DRIVE);
      }else if((uint32_t)(now-state_ms)>PAUSE_MS+TIMEOUT_MS){I_rho=0;enterState(DRIVE);} // drive anyway
      break;
    case DRIVE:
      evalProfile(driveProf,ts,rho_ref,rho_ff);phi_ref=phi_target;phi_ff=0;
      if(ts>=driveProf.T){
        if(settledBoth(dist_target,phi_target,now))enterState(VERIFY_STOP);
        else if(ts*1000>=driveProf.T*1000+TIMEOUT_MS)fail("DRIVE_NOT_SETTLED");
      }break;
    case VERIFY_STOP:
      // Zero outputs, then check the final pose/rates after braking transient.
      if((uint32_t)(now-state_ms)>=VERIFY_STOP_MS){
        if(atRestAndTarget(dist_target,phi_target))enterState(DONE);
        else fail("STOP_DRIFT_OR_MOTION");
      }break;
    case DONE:case FAULT:break;
  }
  bool active=state==TURN || state==PAUSE || state==DRIVE;
  float vr=0,vl=0;
  if(active){
    // Outer loops: position error (m/rad) -> desired speed (m/s or rad/s).
    // Profile velocities provide feedforward; PI corrects tracking/stiction.
    float er=rho_ref-pose.rho,ep=phi_ref-pose.phi;
    float rd0=rho_ff+KP_RHO*er+KI_RHO*I_rho;
    float pd0=phi_ff+KP_PHI*ep+KI_PHI*I_phi;
    float rd=clipValue(rd0,-RHO_DOT_CMD_MAX,RHO_DOT_CMD_MAX);
    float pd=clipValue(pd0,-PHI_DOT_CMD_MAX,PHI_DOT_CMD_MAX);
    // Inner loops: desired speed / identified DC gain + proportional correction.
    // vb is the SUM of the motor voltages; dv is RIGHT minus LEFT.
    float vb=rd/K_RHO+KPV_RHO*(rd-pose.rhod);
    float dv=pd/K_PHI+KPV_PHI*(pd-pose.phid);
    vr=(vb+dv)*0.5f;vl=(vb-dv)*0.5f;
    // Scale both channels together if either exceeds available battery voltage.
    float largest=fmax(fabs(vr),fabs(vl));bool motorSaturated=largest>BATTERY_V;
    if(motorSaturated){vr*=BATTERY_V/largest;vl*=BATTERY_V/largest;}
    // Conditional integration accounts for BOTH rate limits and motor limits.
    // Always allow an existing integral to unwind toward zero.
    if((!motorSaturated && rd==rd0) || er*I_rho<0)
      I_rho=clipValue(I_rho+er*dt,-I_RHO_MAX,I_RHO_MAX);
    if((!motorSaturated && pd==pd0) || ep*I_phi<0)
      I_phi=clipValue(I_phi+ep*dt,-I_PHI_MAX,I_PHI_MAX);
    if(pose.cR!=activityR){activityR=pose.cR;lastActivityR=now;}
    if(pose.cL!=activityL){activityL=pose.cL;lastActivityL=now;}
    if(fabs(vr)<STALL_VOLTAGE)lastActivityR=now;
    if(fabs(vl)<STALL_VOLTAGE)lastActivityL=now;
    if((uint32_t)(now-lastActivityR)>STALL_MS)fail("RIGHT_NO_ENCODER_PROGRESS");
    else if((uint32_t)(now-lastActivityL)>STALL_MS)fail("LEFT_NO_ENCODER_PROGRESS");
  }else{lastActivityR=now;lastActivityL=now;}
  if(state==FAULT || !active){vr=0;vl=0;}
  vr=setMotor(RIGHT_IDX,vr);vl=setMotor(LEFT_IDX,vl);
  if((uint32_t)(now-lastLogMs)>=20){
    lastLogMs=now;
    if(state!=DONE && state!=FAULT){
      Serial.print((now-t0)*0.001f,3);Serial.print('\t');Serial.print((int)state);Serial.print('\t');
      Serial.print(rho_ref,4);Serial.print('\t');Serial.print(pose.rho,4);Serial.print('\t');
      Serial.print(phi_ref,4);Serial.print('\t');Serial.print(pose.phi,4);Serial.print('\t');
      Serial.print(pose.x*M_TO_IN,3);Serial.print('\t');Serial.print(pose.y*M_TO_IN,3);Serial.print('\t');
      Serial.print(vr,3);Serial.print('\t');Serial.println(vl,3);
    }
  }
  if(state==DONE || state==FAULT)reportResult(now);
}
