// This is the motions type file, Wait/Turn/Pause/Drive/Verify_Stop/Done/Fault
// This gives us some header definitions for motion types

#ifndef MOTION_TYPES_H
#define MOTION_TYPES_H
// Header definitions are visible before Arduino generates function prototypes.
struct Profile { float D,a,vp,tA,tC,T; };
enum State { WAIT, TURN, PAUSE, DRIVE, VERIFY_STOP, DONE, FAULT };
#endif
