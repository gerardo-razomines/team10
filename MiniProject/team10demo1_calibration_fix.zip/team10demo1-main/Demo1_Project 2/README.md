# Demo 1 Project
# Team 10

# Calibration fix (after the Demo 1 grade)

Our Demo 1 angle error came from a bad camera calibration, not from the angle math.
The old calibration put the camera's optical center at x = 404 px (it should be close to 320 on a
640 px wide image). That added about a 6 degree error to every angle. The causes were autofocus
changing the lens between photos, a curled paper checkerboard, motion-blurred photos, and a lens
model with too many free parameters. What was changed:

- **vision_common.py** turns autofocus off and locks the focus at the value used during calibration.
  It also applies a constant trim (`angle_offset_deg`) and reports the median of the last 15 frames.
- **calibrate_camera.py** uses a simpler lens model (no tangential distortion, no k3). It only saves
  photos while the board is held still, throws out bad photos, and **refuses to save** a calibration
  whose optical center is off, whose fx and fy don't match, or where the board didn't reach the
  edges of the image.
- **verify_angle.py** (new) checks the reported angle against marker positions measured with a
  tape measure, and can save the constant trim to `camera_config.json`.
- The old bad `camera_calibration.npz` and the old photos were deleted, so a new calibration is required.

## One-time setup on the Pi
1. Print `checkerboard_9x6.svg` at 100% scale and tape it **flat** to cardboard or a clipboard.
2. `python3 calibrate_camera.py --force` and move the board slowly. Hold it still at each spot,
   tilt it 30-45 degrees left/right/up/down, and get it into all four corners of the image.
   If the calibration is refused, read the reason and try again.
3. `python3 verify_angle.py` and check at least 5 measured marker spots (1-5 ft, left and right).
   Save the trim when it asks. The average error should be well under 0.75 degrees.
4. `python3 marker_angle.py` for the demo.

Keep the camera at 640x480 and don't change the focus after calibrating.

# How to Run: 

You run the arduino side by uploading the code to the arduino attached to the robot and then you just turn on the battery for the robot. 

You run the pi side by just running project.py and picking which of the tasks you want to accomplish.

# There are 3 parts to this project:

# For Pi
 The pi folders use the USB camera to detect the ArUco markers and it calculates the horizontal angle that's relative to the camera's direction as it's straight ahead.
 It displays the ID 0's angle on the LCD. 
 It makes left positive and right negative.

# The Camera Calibration
This uses a series of checkerboard pictures in order to estimate the camera properties and the lens distortion.
The saved calibration is reused for the angle measurements.
The preview and the shared utilities and the configuration files will support the cameras operation.

# Arduino
This uses the wheel encoders in order to estimate the distance and the heading and the position.
It also adjusts the motor voltages with feedback control.
This allows it to turn to a specified heading and then it will drive a specified distance.
And the current sketch is set to 180 degrees.
Then its followed by a foot after a 1 second delay.
But you can always change those.


# Terminal Menu
This allows for camera and LCD tests, it's part of the Pi code. 


# Pi Files Explained:

**project.py** runs the terminal menu for the camera tests, LCD tests, calibration. An older version made the arduino movement runs but those no longer work!

**marker_angle.py** detects the ArUco marker ID 0. It continues to display the horizontal angle on the physical LCD. 

**calibrate_camera.py** this uses the checkerboard images in order to calculate and save the camera's calibration values for angle measurements that are accurate. 

**verify_angle.py** checks the angles against tape-measure positions and saves a constant trim

**camera_preview.py** this handles a live camera preview and it helps the script run without a display

**vision_common.py** this provides shared functions in order to open the camera, detect markers, load calibration, and also calculate marker angles

**run_project.sh** this begins the project by using the right environment for python with an option to run the camera and LCD task 

**camera_config.json** this just stores settings for the camera, marker selectino, image orientation, calibration location and also the dimensions for the LCD

**requirements.txt** this just shows the python packages that are required to run the pi programs.

# Arduino Files Explained:

**Demo1_Motion.ino** this just runs the robot's turn-then-drive sequence. It uses encoded feedback to adjust the voltages for the motor. 

**RobotConfig.h** this stores the hardware settings, the wheel dimesnions, the motor and encoding signs, the controller gains, and the movement limits

**RobotIO.h** this reads the wheel encoders, estimates the robot position and the heading, and it controls the motor direction and its voltage

**MotionTypes.h** this defines the motion-profile structure and the states that are used to organize the sequence for the movement


# MATLAB Files

**capture_robot_step.m** this records arduino serial data from movement/identification teests and it saves it for analysis

**identify_robot.m** this uses recorded forward and rotation tests in order to estimate mathematical models of the robots motion

**design_robot_controllers.m** thsi simulates the robot thats using configured controlller gains and it plots its distance, heading, along with motor voltages and its path. 

# Extra Files

**camera_calibration.npz** this contains saved camera calibration results that the python programs will load for their angle measurements

**checkerboard_9x6.svg** this just gives the printable checkerboard pattern thats used for camera calibration

**calibration_views_XXX/** gets created when you calibrate. It holds the checkerboard photos from that session

**readme.md** what youre reading right now and youre getting all the info on everything here.



# There are no diagrams for this since the Localizations and Controls Side didn't make any.