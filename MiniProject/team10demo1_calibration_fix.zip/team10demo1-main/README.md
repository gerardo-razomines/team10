# Demo 1 Project
# Team 10

# How to Run: 

You run the arduino side by uploading the code to the arduino attached to the robot and then you just turn on the battery for the robot. 

You run the pi side by just running project.py and picking which of the tasks you want to accomplish.

# There are 3 parts to this project:

# For Pi
 The pi folders use the USB camera to detect the ArUco markers and it calculates the horizontal angle that's relative to the camera's direction as it's straight ahead.
 It displays the ID 0's angle on the LCD. 
 It makes left positive and right negative.

# The Camera Calibration
This uses a series of checkerboard pictures in order to estimate the camera properties and the lens distortion.
The saved calibration is reused for the angle measurements.
The preview and the shared utilities and the configuration files will support the cameras operation.

# Arduino
This uses the wheel encoders in order to estimate the distance and the heading and the position.
It also adjusts the motor voltages with feedback control.
This allows it to turn to a specified heading and then it will drive a specified distance.
And the current sketch is set to 180 degrees.
Then its followed by a foot after a 1 second delay.
But you can always change those.


# Terminal Menu
This allows for camera and LCD tests, it's part of the Pi code. 


# Pi Files Explained:

**project.py** runs the terminal menu for the camera tests, LCD tests, calibration. An older version made the arduino movement runs but those no longer work!

**marker_angle.py** detects the ArUco marker ID 0. It continues to display the horizontal angle on the physical LCD. 

**calibrate_camera.py** this uses the checkerboard images in order to calculate and save the camera's calibration values for angle measurements that are accurate. 

**camera_preview.py** this handles a live camera preview and it helps the script run without a display

**vision_common.py** this provides shared functions in order to open the camera, detect markers, load calibration, and also calculate marker angles

**run_project.sh** this begins the project by using the right environment for python with an option to run the camera and LCD task 

**camera_config.json** this just stores settings for the camera, marker selectino, image orientation, calibration location and also the dimensions for the LCD

**requirements.txt** this just shows the python packages that are required to run the pi programs.

# Arduino Files Explained:

**Demo1_Motion.ino** this just runs the robot's turn-then-drive sequence. It uses encoded feedback to adjust the voltages for the motor. 

**RobotConfig.h** this stores the hardware settings, the wheel dimesnions, the motor and encoding signs, the controller gains, and the movement limits

**RobotIO.h** this reads the wheel encoders, estimates the robot position and the heading, and it controls the motor direction and its voltage

**MotionTypes.h** this defines the motion-profile structure and the states that are used to organize the sequence for the movement


# MATLAB Files

**capture_robot_step.m** this records arduino serial data from movement/identification teests and it saves it for analysis

**identify_robot.m** this uses recorded forward and rotation tests in order to estimate mathematical models of the robots motion

**design_robot_controllers.m** thsi simulates the robot thats using configured controlller gains and it plots its distance, heading, along with motor voltages and its path. 

# Extra Files

**camera_calibration.npz** this contains saved camera calibration results that the python programs will load for their angle measurements

**checkerboard_9x6.svg** this just gives the printable checkerboard pattern thats used for camera calibration

**everything under calibration_views_XXX/** this has checkerboard photographs and capture settings that are retained from calibration sessions

**readme.md** what youre reading right now and youre getting all the info on everything here.

**pycache** this just has all of the python cache files that helped the modules load quicker.


# There are no diagrams for this since the Localizations and Controls Side didn't make any.
